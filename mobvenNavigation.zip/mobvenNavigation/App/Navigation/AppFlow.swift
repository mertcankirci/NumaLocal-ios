//
//  AppFlow.swift
//  mobvenNavigation
//
//  Created by Mertcan Kırcı on 15.07.2025.
//

import Foundation

enum AppFlow { case welcome, onboarding, main }
