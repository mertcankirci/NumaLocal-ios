//
//  SelectableOption+Ext.swift
//  mobvenNavigation
//
//  Created by Mertcan Kırcı on 16.07.2025.
//

import SwiftUI

extension SelectableOption {
    var font: Font { .body } // default
}
