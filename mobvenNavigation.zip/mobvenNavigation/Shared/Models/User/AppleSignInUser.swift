//
//  AppleSignInUser.swift
//  mobvenNavigation
//
//  Created by Mertcan Kırcı on 16.07.2025.
//

import Foundation

struct AppleSignInUser {
    let userId: String
    let fullName: String?
    let email: String?
}
