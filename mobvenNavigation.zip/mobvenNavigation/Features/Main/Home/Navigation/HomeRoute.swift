//
//  HomeRoute.swift
//  mobvenNavigation
//
//  Created by Mertcan Kırcı on 16.07.2025.
//

import Foundation

enum HomeRoute: Hashable {
    case detail(itemID: String)
}
